//import anime from 'bower_components/animejs/'

window.onload = function(){

}

function drop(){
  console.log("hello");
}
